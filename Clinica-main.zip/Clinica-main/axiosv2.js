const axios = require('axios');
const fs = require('fs');
const { parse } = require('path');

// Ruta al archivo .js que quieres cargar
const filePath = './data1.json';
console.log(filePath)
// Lee el contenido del archivo
fs.readFile(filePath, 'utf8', (err, data) => {
  if (err) {
    console.error('Error al leer el archivo:', err);
    return;
  }

  let fileData;
  try {
    fileData = JSON.parse(data)
  } catch (parsErr) {
    
  }
  console.log(fileData)
  // Realiza la solicitud POST con Axios
  const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NjU4NmU4NzI2YzRlOGQ1NDVlYTYyNDIiLCJyb2xlIjoiYWRtaW4iLCJpYXQiOjE3MTcxNzA0MDksImV4cCI6MTcxNzE3NDAwOX0.D7cPLDg5NexnSbum8ggctDhc1D8Szww2DWEK8D_8_Zs";

axios.post('http://localhost:3000/reportes/multiple', fileData, {
  headers: {
    Authorization: `Bearer ${token}`
  }
})
    .then(response => {
      console.log('Respuesta del servidor:', response.data);
    })
    .catch(error => {
      console.error('Error al enviar la solicitud:', error);
    });
});
