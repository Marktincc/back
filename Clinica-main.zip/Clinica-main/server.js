    require('dotenv').config();
    const express = require('express');
    const PORT = process.env.PORT || 3000
    const dataBaseConnection = require('./config/mongo');
    const router = require('./src/v1/routes/routes.js');
    const cors = require('cors');
    const bodyParser = require('body-parser');

    const app = express();

    app.use(cors());
    app.use(bodyParser.json({limit:'1000mb'}));
    app.use(bodyParser.urlencoded({ extended: true }));
    router(app);
    app.use('/imagenes', express.static('uploads'));
    dataBaseConnection()
    app.listen(PORT, () => {
        console.log('Connected to the PORT', PORT);
    });
