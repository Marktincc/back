// config/multer.js
const multer = require('multer');
const sharp = require('sharp');
const path = require('path');

const storage = multer.memoryStorage();

const upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        const filetypes = /webp|jpg|jpeg|png/;
        const mimetype = filetypes.test(file.mimetype);
        const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
        if (mimetype && extname) {
            return cb(null, true);
        }
        cb('Error: Solo se permiten archivos WebP, PNG, JPG o JPEG');
    },
});

const processImages = async (images) => {
    const processedImages = [];
    if (!images || images.length === 0) {
        return processedImages;
    }

    for (const image of images) {
        const filename = `image_${Date.now()}_${Math.floor(Math.random() * 1000)}.webp`;
        await sharp(image.buffer)
            .webp()
            .toFile(`uploads/${filename}`);
        processedImages.push(filename);
    }

    return processedImages;
};

module.exports = { upload, processImages };