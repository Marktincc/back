"document": 12345,
  "password": "$2a$10$4bnTqOHJczJV9m30eIssTOgkoDqySIfggA4ooGjC3o.Hkf2XWYmBm",
  "role": "admin"