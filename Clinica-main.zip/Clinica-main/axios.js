const axios = require('axios');

const reports = [
  {
    "createdAt": "",
    "floor": 5,
    "room": 2,
    "request": "62950000",
    "damageType": "Solicito su amable colaboración con revisión de timbre uci plena 2, quinto piso ya que no esta funcionando.",
    "diagnosis": "Se valida en el servicio y se va a la habitación reportada y no presenta falla.",
    "image": "//10.70.10.67/timbres/fotos/p1 f1. reanima A.jpg",
    "completionDate": "07/01/2021",
    "status": "completado",
    

  },
  {
    "createdAt": "",
    "floor": 2,
    "room": 39,
    "request": "63004900",
    "damageType": "El motivo de la presente es para reportar sobre que no funciona timbre de la cama 36, 39",
    "diagnosis": "Se revisa y se encuentra desconectado de la base",
    "image": "fotos/07_01_21 p.2 f.2 _63021700.jfif",
    "completionDate": "",
    "status": "completado"
   },
];
const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI2NjU4NmU4NzI2YzRlOGQ1NDVlYTYyNDIiLCJyb2xlIjoiYWRtaW4iLCJpYXQiOjE3MTcxMDQwNzMsImV4cCI6MTcxNzEwNzY3M30.freDszioD61Ap_MRsOLXasy6bAJD1T34Phr0QlsJcIM";

axios.post('http://localhost:3000/reportes/multiple', reports, {
  headers: {
    Authorization: `Bearer ${token}`
  }
})
  .then(response => {
    console.log('Respuesta del servidor:', response.data);
  })
  .catch(error => {
    console.error('Error al enviar la solicitud:', error);
  });
