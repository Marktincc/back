require('dotenv').config();
const jwt = require('jsonwebtoken');
const secretKey = process.env.SECRET_KEY;
const authenticateToken = require('../../middleware/authenticateToken'); // Importa el middleware de autenticación

const routes = function (server) {
  console.log('Starting');
  
  // Aquí puedes definir qué rutas requieren qué roles
  server.use('/inicioSesion', require('./login.route'));
  
  // Aquí, por ejemplo, permitimos que tanto usuarios normales como administradores accedan a algunas rutas dentro de /reportes
  server.use('/reportes', authenticateToken(), require('./reportRoutes.route'));
};

module.exports = routes;
