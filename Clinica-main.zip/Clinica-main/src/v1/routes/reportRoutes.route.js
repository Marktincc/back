const express = require('express');
const { upload } = require('../../../config/multer');
const router = express.Router();
const reportController = require('../../controller/reportController');
const authenticateToken = require('../../middleware/authenticateToken'); 

// Rutas accesibles solo para administradores
router.post('/create', authenticateToken('admin'), upload.single('image'), reportController.createReport);
router.post('/:reportId/completeReport', authenticateToken('admin'), upload.single('image'), reportController.completeReport);
router.put('/updateStatus/:reportId', authenticateToken('admin'), reportController.updateReportStatus);
router.get('/allReports', authenticateToken(), reportController.getAllReports);
router.get('/:reportId/status', authenticateToken('admin'), reportController.getReportStatusById);

router.post('/multiple', authenticateToken('admin'), reportController.createMultipleReports); // Utiliza router.post para asignar la ruta al método




// Rutas accesibles para usuarios y administradores
router.get('/damagedRoomsByFloor/:floor', authenticateToken(), reportController.getDamagedRoomsByIdFloor); // Aquí aplicamos el middleware a la ruta para permitir acceso a usuarios y administradores
router.get('/damagedRoomsByFloor', authenticateToken(), reportController.getDamagedRoomsByFloor);
router.get('/reportsByMonth/:year', authenticateToken(), reportController.getReportsByMonth);
router.get('/statusCounts', authenticateToken(), reportController.getReportStatusCounts);
router.get('/damagedRoomsByMonth/:year/:month', authenticateToken(), reportController.getDamagedRoomsByMonth);
router.get('/averageRepairTimeByMonth', authenticateToken(), reportController.getAverageRepairTimeByMonth);
router.get('/getDamagedRoomsByYear/:year', authenticateToken(), reportController.getDamagedRoomsByYear);

router.get('/getDamagedRoomsByDateRange/:startDate/:endDate', authenticateToken(), reportController.getDamagedRoomsByDateRange);
router.get('/getReportById/:reportId', authenticateToken(), reportController.getReportById);

module.exports = router;
