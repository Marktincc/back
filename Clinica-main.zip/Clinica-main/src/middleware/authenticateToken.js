const jwt = require('jsonwebtoken');
const secretKey = process.env.SECRET_KEY;

const authenticateToken = (requiredRole) => (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.sendStatus(401); // Si no hay token, retorna un error de no autorizado
  }

  jwt.verify(token, secretKey, (err, user) => {
    if (err) {
      return res.sendStatus(403); // Si hay un error en la verificación del token, retorna un error de prohibido
    }
    req.user = user; // Agrega el usuario al objeto req para que esté disponible en las siguientes capas de la aplicación
    
    // Si no se especifica un rol requerido o el usuario tiene el rol requerido, permite el acceso
    if (!requiredRole || req.user.role === requiredRole) {
      return next();
    }
    
    // Si el usuario no tiene el rol necesario, retorna un error de prohibido
    return res.sendStatus(403);
  });
};

module.exports = authenticateToken;
