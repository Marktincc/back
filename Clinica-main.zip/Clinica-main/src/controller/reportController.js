// controllers/reportController.js
const { upload, processImages } = require('../../config/multer');
const Apartment = require('../models/apartmentModel');
const response = require('../helpers/response');
const sharp = require('sharp');
const sizeOf = require('image-size')
const createReport = async (req, res) => {
    try {
        const {
            floor,
            room,
            request,
            damageType,
            status,
            diagnosis,
            responsible,            
        } = req.body;

        // Validar los campos obligatorios
        if (!floor || !room || !request || !damageType || !status) {
            return response.error(req, res, 'Faltan campos obligatorios', 400);
        }

        let filename = null;
        const file = req.file;
        console.log('Archivo recibido:', file);


        // Procesar la imagen con Sharp si se proporciona
        if (file) {
            const file = req.file;
            filename = `image_${Date.now()}.webp`;
            console.log(filename)
            await sharp(file.buffer).webp().toFile(`uploads/${filename}`);
        }

        // Generar la fecha actual como la fecha en la que se completó el informe si el estado es "completado"
        let completionDate = null;
        if (status === "completado") {
            completionDate = new Date();
        }
        

        const newReport = new Apartment({
            reportId: `report_${Date.now()}`,
            floor,
            room,
            request,
            damageType,
            photos: filename ? [filename] : [], // añadir la imagen si se proporciona
            status,
            diagnosis,
            responsible,
            completionDate, // incluir la fecha de finalización en el nuevo informe
        });

        await newReport.save();

        response.success(req, res, { reportId: newReport.reportId }, 201);
    } catch (error) {
        console.error(error);
        response.error(req, res, 'Error al crear el reporte', 500);
    }
};



const updateReportStatus = async (req, res) => {
    try {
        // Obtener _id de los parámetros de la URL
        const reportId = req.params.reportId;
        const { newStatus } = req.body;

        // Validar que el nuevo estado sea uno de los valores permitidos
        const allowedStatusValues = ["pendiente", "en curso",];
        if (!allowedStatusValues.includes(newStatus)) {
            return response.error(req, res, 'Valor de estado no válido', 400);
        }

        // Utilizar el método findOneAndUpdate de Mongoose para actualizar el documento
        const report = await Apartment.findOneAndUpdate(
            { _id: reportId }, // Utilizando el _id de la URL como criterio de búsqueda
            { status: newStatus },
            { new: true }
        );

        // Verificar si el informe no fue encontrado en la base de datos
        if (!report) {
            return response.error(req, res, 'Reporte no encontrado', 404);
        }

        // Responder con éxito y enviar el informe actualizado
        response.success(req, res, report, 200);
    } catch (error) {
        // Manejar cualquier error que pueda ocurrir durante el proceso
        console.error(error);
        response.error(req, res, 'Error al actualizar el estado del reporte', 500);
    }
};
const getDamagedRoomsByFloor = async (req, res) => {
    try {
        // Realizar una consulta para obtener los informes agrupados por piso y habitación
        const damageStats = await Apartment.aggregate([
            {
                $group: {
                    _id: {
                        floor: "$floor",
                        room: "$room",
                    },
                    totalDamage: { $sum: 1 },
                },
            },
            {
                $sort: { totalDamage: -1 }, // Ordenar en orden descendente por totalDamage
            },
        ]);

        // Responder con la lista ordenada de habitaciones dañadas por piso
        response.success(req, res, damageStats, 200);
    } catch (error) {
        // Manejar errores
        console.error(error);
        response.error(req, res, 'Error al obtener estadísticas de daños por piso', 500);
    }
};
const getDamagedRoomsByIdFloor = async (req, res) => {
    try {
        // Obtener el piso específico desde los parámetros de la solicitud
        const { floor } = req.params;

        // Obtener las fechas de inicio y fin desde los parámetros de la solicitud
        const { startDate, endDate } = req.query;

        // Verificar que las fechas estén presentes
        if (!startDate || !endDate) {
            return response.error(req, res, 'Faltan las fechas de inicio o fin', 400);
        }

        // Convertir las fechas a objetos Date
        const start = new Date(startDate);
        const end = new Date(endDate);
        console.log(floor + 'pepe')
        // Realizar una consulta para obtener los informes agrupados por piso y habitación
        const damageStats = await Apartment.aggregate([
            {
                $match: {
                    floor: parseInt(floor), // Convertir el piso a un número si es necesario
                    createdAt: {
                        $gte: start, // Filtrar por fecha de inicio
                        $lte: end,   // Filtrar por fecha de fin
                    },
                },
            },
            {
                $group: {
                    _id: {
                        floor: "$floor",
                        room: "$room",
                    },
                    totalDamage: { $sum: 1 },
                },
            },
            {
                $sort: { totalDamage: -1 }, // Ordenar en orden descendente por totalDamage
            },
        ]);

        // Responder con la lista ordenada de habitaciones dañadas por piso+
        console.log(damageStats)
        response.success(req, res, damageStats, 200);
    } catch (error) {
        // Manejar errores
        console.error(error);
        response.error(req, res, 'Error al obtener estadísticas de daños por piso', 500);
    }
};
const getAllReports = async (req, res) => {
    try {
        // Retrieve all reports from the database
        const allReports = await Apartment.find();

        // Respond with the list of all reports
        response.success(req, res, allReports, 200);
    } catch (error) {
        // Handle errors
        console.error(error);
        response.error(req, res, 'Error al obtener todos los informes', 500);
    }
};
const getDamagedRoomsByMonth = async (req, res) => {
    try {
        // Obtener el año y mes desde los parámetros de la solicitud
        const { year, month } = req.params;

        // Validar que se proporcionen ambos parámetros
        if (!year || !month) {
            return response.error(req, res, 'Se requieren año y mes para la consulta', 400);
        }

        // Convertir año y mes a números enteros
        const intYear = parseInt(year);
        const intMonth = parseInt(month);

        // Validar que los números sean válidos
        if (isNaN(intYear) || isNaN(intMonth) || intMonth < 1 || intMonth > 12) {
            return response.error(req, res, 'Año o mes no válido', 400);
        }

        // Realizar una consulta para obtener los informes agrupados por piso y habitación en un mes específico
        const damageStats = await Apartment.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: new Date(intYear, intMonth - 1, 1), // Restar 1 al mes ya que los meses van de 0 a 11 en JavaScript
                        $lt: new Date(intYear, intMonth, 1),
                    },
                },
            },
            {
                $group: {
                    _id: {
                        floor: "$floor",
                        room: "$room",
                    },
                    totalDamage: { $sum: 1 },
                },
            },
            {
                $sort: { totalDamage: -1 }, // Ordenar en orden descendente por totalDamage
            },
        ]);

        // Responder con la lista ordenada de habitaciones dañadas por piso en el mes específico
        response.success(req, res, damageStats, 200);
    } catch (error) {
        // Manejar errores
        console.error(error);
        response.error(req, res, 'Error al obtener estadísticas de daños por mes', 500);
    }
};
const getReportsByMonth = async (req, res) => {
    try {
        // Obtener el año desde los parámetros de la solicitud
        const { year } = req.params;

        // Validar que se proporcione el año
        if (!year) {
            return response.error(req, res, 'Se requiere el año para la consulta', 400);
        }

        // Convertir el año a número entero
        const intYear = parseInt(year);

        // Validar que el número sea válido
        if (isNaN(intYear)) {
            return response.error(req, res, 'Año no válido', 400);
        }

        // Realizar una consulta para obtener los informes del año especificado
        const reportsByYear = await Apartment.aggregate([
            {
                $match: {
                    $expr: { $eq: [{ $year: "$createdAt" }, intYear] }, // Filtrar por año
                },
            },
            {
                $group: {
                    _id: { $month: "$createdAt" }, // Agrupar por mes
                    count: { $sum: 1 },
                },
            },
            {
                $sort: { _id: 1 }, // Ordenar por mes
            },
        ]);

        // Responder con los informes agrupados por mes
        response.success(req, res, reportsByYear, 200);
    } catch (error) {
        // Manejar errores
        console.error(error);
        response.error(req, res, 'Error al obtener informes por año', 500);
    }
};


const getAverageRepairTimeByMonth = async (req, res) => {
    try {
        // Calculate the average repair time for each month
        const averageRepairTimeByMonth = await Apartment.aggregate([
            {
                $group: {
                    _id: { $month: "$createdAt" },
                    averageRepairTime: {
                        $avg: {
                            $subtract: ["$repairDate", "$createdAt"],
                        },
                    },
                },
            },
            {
                $sort: { _id: 1 }, // Sort by month
            },
        ]);

        // Respond with the results
        response.success(req, res, averageRepairTimeByMonth, 200);
    } catch (error) {
        console.error(error);
        response.error(req, res, "Error getting average repair time by month", 500);
    }
};

const getReportStatusCounts = async (req, res) => {
    try {
        // Realiza una consulta para contar los informes agrupados por estado
        const reportCounts = await Apartment.aggregate([
            {
                $group: {
                    _id: "$status",
                    count: { $sum: 1 },
                },
            },
        ]);

        // Formatea el resultado para tener un objeto con el número de informes en cada estado
        const statusCounts = {};
        reportCounts.forEach((item) => {
            statusCounts[item._id] = item.count;
        });

        // Responde con el objeto de recuento de estado
        response.success(req, res, statusCounts, 200);
    } catch (error) {
        // Manejar errores
        console.error(error);
        response.error(req, res, 'Error al obtener el recuento de estados de informes', 500);
    }
};
const getReportStatusById = async (req, res) => {
    try {
        // Obtener el ID del informe de los parámetros de la URL
        const reportId = req.params.reportId;

        // Buscar el informe por su ID
        const report = await Apartment.findById(reportId);

        // Verificar si el informe existe
        if (!report) {
            return response.error(req, res, 'Informe no encontrado', 404);
        }

        // Responder con el estado del informe
        response.success(req, res, { status: report.status }, 200);
    } catch (error) {
        // Manejar errores
        console.error(error);
        response.error(req, res, 'Error al obtener el estado del informe por ID', 500);
    }
};
const completeReport = async (req, res) => {
    try {
        // Obtener el ID del informe de los parámetros de la URL
        const reportId = req.params.reportId;

        // Obtener la información necesaria del cuerpo de la solicitud
        const { diagnosis, responsible } = req.body;
        const file = req.file;

        // Asegúrate de que se haya proporcionado una imagen
        if (!file) {
            return response.error(req, res, 'No se ha proporcionado una imagen', 400);
        }

        // Procesa la imagen con Sharp para convertirla a webp y asignarle un nombre único
        const filename = `image_${Date.now()}.webp`;
        await sharp(file.buffer).webp().toFile(`uploads/${filename}`);

        // Generar la fecha actual como la fecha en la que se completó el informe
        const completionDate = new Date();
        console.log(completionDate)

        // Actualizar el informe con el nuevo estado, la información proporcionada y la imagen
        const report = await Apartment.findByIdAndUpdate(
            reportId,
            {
                status: "completado",
                photos: [filename],
                diagnosis,
                responsible,
                completionDate
            },
            { new: true }
        );

        // Verificar si el informe existe
        if (!report) {
            return response.error(req, res, 'Informe no encontrado', 404);
        }

        // Responder con el informe actualizado
        response.success(req, res, report, 200);
    } catch (error) {
        // Manejar errores
        console.error(error);
        response.error(req, res, 'Error al completar el informe', 500);
    }
};



const parseDate = (dateStr) => {
    if (!dateStr || typeof dateStr !== 'string') {
        // Si dateStr es nulo o vacío, asignamos la fecha actual
        const currentDate = new Date();
        console.log("Fecha predeterminada asignada:", currentDate);
        return currentDate.toISOString();
    }
    
    console.log(dateStr + 'mondaa');
    const [day, month, year] = dateStr.split('/').map(part => parseInt(part, 10));
    if (isNaN(day) || isNaN(month) || isNaN(year)) {
        throw new Error('Formato de fecha inválido');
    }
    const date = new Date(Date.UTC(year, month - 1, day, 0, 0, 0));
    console.log(month);
    console.log(date + "monda1");
    const formattedDate = date.toISOString();
    console.log(formattedDate + 'mondaa2');
    return formattedDate;
};

const createMultipleReports = async (req, res) => {
    try {
        const reports = req.body; // Obtener los reportes del cuerpo de la solicitud

        // Validar que se proporcionen reportes
        if (!reports || !Array.isArray(reports)) {
            return response.error(req, res, 'Se requiere un arreglo de reportes en el cuerpo de la solicitud', 400);
        }
        
        // Iterar sobre cada reporte y procesarlo
        for (const report of reports) {
            const {
                floor,
                room,
                request,
                damageType,
                image,
                diagnosis,
                completionDate,
                createdAt,
                status,
                responsible,
            } = report;

            // Validar los campos obligatorios
            if (!floor || !room || !request || !damageType) {
                console.log(`Reporte incompleto: ${JSON.stringify(report)}`);
                continue; // Saltar este reporte y continuar con el siguiente
            }

            let filename = null;

            // Procesar la imagen con Sharp si se proporciona y es válida
            if (image) {
                try {
                    sizeOf(image); // Esto lanzará un error si los datos no son una imagen válida
                    filename = `image_${Date.now()}.webp`;
                    await sharp(image).webp().toFile(`uploads/${filename}`);
                } catch (error) {
                    console.log('La imagen proporcionada no es válida');
                }
            }

            // Generar la fecha de creación automáticamente si no se proporciona
            
            // let createdAt1 = createdAt => valor === null ? new Date() : valor;
            console.log(createdAt + 'david')
            let createdAt1 = createdAt
            let parsedCreatedAt = parseDate(createdAt1);
            console.log(parsedCreatedAt + "pepe")

            if (!parsedCreatedAt || isNaN(Date.parse(parsedCreatedAt))) {
                parsedCreatedAt = new Date().toISOString();
                console.log(parsedCreatedAt + "pepe")
            } else if (createdAt && !isNaN(new Date(createdAt).getTime())) {
                // parsedCreatedAt = new Date(createdAt).toISOString();
                console.log(parsedCreatedAt + "pepe1")

            }
            
            // Convertir la fecha de finalización de cadena a objeto de fecha de JavaScript si está presente
            let completionDate1 = completionDate
            let parsedCompletionDate = parseDate(completionDate1);
            if (!parsedCompletionDate || isNaN(Date.parse(parsedCompletionDate))) {
                parsedCompletionDate = new Date().toISOString();
            } else if (completionDate && !isNaN(new Date(completionDate).getTime())) {
                // parsedCompletionDate = new Date(completionDate).toISOString();
                console.log(parsedCompletionDate)
            }
            const newReport = new Apartment({
                floor,
                room,
                request,
                damageType,
                status,
                diagnosis,
                responsible,
                photos: filename ? [filename] : [], // añadir la imagen si se proporciona
                completionDate: parsedCompletionDate, // incluir la fecha de finalización en el nuevo informe
                createdAt: parsedCreatedAt // incluir la fecha de creación en el nuevo informe
            });

            await newReport.save();
        }

        response.success(req, res, 'Reportes guardados exitosamente', 201);
    } catch (error) {
        console.error(error);
        response.error(req, res, 'Error al crear los reportes', 500);
    }
};
const getDamagedRoomsByYear = async (req, res) => {
    try {
        const { year } = req.params; // Asumiendo que se pasa el año como parámetro en la URL

        // Realizar una consulta para obtener los informes agrupados por año, piso y habitación
        const damageStats = await Apartment.aggregate([
            {
                $match: { // Filtrar por el año especificado
                    createdAt: {
                        $gte: new Date(`${year}-01-01`), // Fecha de inicio del año
                        $lt: new Date(`${year}-12-31T23:59:59.999Z`), // Fecha de fin del año
                    }
                }
            },
            {
                $group: {
                    _id: {
                        year: { $year: "$createdAt" }, // Agrupar por año
                        floor: "$floor",
                        room: "$room",
                    },
                    totalDamage: { $sum: 1 },
                },
            },
            {
                $match: { // Filtrar por totalDamage mayor a 5
                    totalDamage: { $gt: 5 }
                }
            },
            {
                $sort: { "totalDamage": -1 } // Ordenar en orden descendente por totalDamage
            }
        ]);

        // Responder con la lista ordenada de habitaciones dañadas por año
        response.success(req, res, damageStats, 200);
    } catch (error) {
        // Manejar errores
        console.error(error);
        response.error(req, res, 'Error al obtener estadísticas de daños por año', 500);
    }
};
const getDamagedRoomsByDateRange = async (req, res) => {
    try {
        // Obtener el rango de fechas desde los parámetros de la solicitud
        const { startDate, endDate } = req.params;

        // Validar que se proporcionen ambas fechas
        if (!startDate || !endDate) {
            return response.error(req, res, 'Se requieren fecha de inicio y fecha de fin para la consulta', 400);
        }

        // Convertir las fechas a objetos Date
        const start = new Date(startDate);
        const end = new Date(endDate);

        // Validar que las fechas sean válidas
        if (isNaN(start.getTime()) || isNaN(end.getTime()) || start >= end) {
            return response.error(req, res, 'Fechas no válidas', 400);
        }

        // Realizar una consulta para obtener los informes agrupados por piso y habitación en el rango de fechas
        const damageStats = await Apartment.aggregate([
            {
                $match: {
                    createdAt: {
                        $gte: start,
                        $lt: end,
                    },
                },
            },
            {
                $group: {
                    _id: {
                        floor: "$floor",
                        room: "$room",
                    },
                    totalDamage: { $sum: 1 },
                },
            },
            {
                $sort: { totalDamage: -1 }, // Ordenar en orden descendente por totalDamage
            },
        ]);

        // Responder con la lista ordenada de habitaciones dañadas por piso en el rango de fechas
        response.success(req, res, damageStats, 200);
    } catch (error) {
        // Manejar errores
        console.error(error);
        response.error(req, res, 'Error al obtener estadísticas de daños por rango de fechas', 500);
    }
};
const getReportById = async (req, res) => {
    try {
      // Obtener el ID del informe de los parámetros de la URL
      const reportId = req.params.reportId;

      // Buscar el informe por su ID en la base de datos
      const report = await Apartment.findById(reportId);

      // Verificar si el informe existe
      if (!report) {
        return response.error(req, res, 'Informe no encontrado', 404);
      }

      // Responder con el informe encontrado
      response.success(req, res, report, 200);
    } catch (error) {
      // Manejar errores
      console.error(error);
      response.error(req, res, 'Error al obtener el informe por ID', 500);
    }
  };

module.exports = { createReport, updateReportStatus, getDamagedRoomsByFloor, getDamagedRoomsByIdFloor, getAllReports, getDamagedRoomsByMonth, getReportsByMonth, getAverageRepairTimeByMonth, getReportStatusCounts, getReportStatusById, completeReport, createMultipleReports, getDamagedRoomsByYear, getDamagedRoomsByDateRange,getReportById };