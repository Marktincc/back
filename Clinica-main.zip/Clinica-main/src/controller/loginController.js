const jwt = require('jsonwebtoken');
const { compare } = require('../helpers/handleBcrypt.js');
const response = require('../helpers/response');
const userModel = require('../models/userModel');
const error = require('../constants');
require('dotenv').config();

const secretKey = process.env.SECRET_KEY; // Asegúrate de tener una clave secreta en tu archivo de configuración


const loginController = async (req, res) => {
    try {
        const { user_email, user_password } = req.body;
        const normalizedEmail = user_email.toLowerCase(); // Convertir el correo electrónico a minúsculas
        const user = await userModel.findOne({ document: normalizedEmail });

        if (!user) {
            return response(req, res, error.ERROR_RESPONSES.not_found, 401);
        }

        const comparing = await compare(user_password, user.password);
        console.log(comparing)
        if (comparing) {
            // Generar JWT
            const token = jwt.sign({ userId: user._id, role: user.role }, secretKey, { expiresIn: '1h' });
            // Devolver JWT y rol del usuario
            response.success(req, res, { token: token, role: user.role }, 200);
        } else {
            response.error(req, res, error.ERROR_RESPONSES.invalid);
        }
    } catch (e) {
        response.error(req, res, error.ERROR_RESPONSES.unexpected);
        console.error(e);
    }
};

module.exports = { loginController };
