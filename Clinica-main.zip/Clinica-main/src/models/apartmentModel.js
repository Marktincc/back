const mongoose = require('mongoose');

const apartmentSchema = new mongoose.Schema(
    {
        floor: {
            type: Number,
            required: true,
            min: 1,
            max: 9,
        },
        room: {
            type: String,
            required: true,
        },
        request: {
            type: String,
            required: true,
        },
        damageType: {
            type: String,
            required: true,
        },
        diagnosis: {
            type: String,
            // required: true,
            default: null, // Campo que puede ser nulo si no se proporciona ningún valor
        },
        photos: {
            type: [String], // Puedes almacenar rutas de archivos o enlaces a las fotos
            default: [],
        },
        repairDate: {
            type: Date,
        },
        responsible: {
            type: String,
            // required: true,
            default: null, // Campo que puede ser nulo si no se proporciona ningún valor
        },
        completionDate: {
            type: Date,
            default: null, // Campo que puede ser nulo si no se proporciona ningún valor
        },
        status: {
            type: String,
            enum: ['completado','en curso', 'pendiente'],
            default: 'pendiente',
        },
    },
    {
        timestamps: true,
    }
);

const Apartment = mongoose.model('Apartment', apartmentSchema);

module.exports = Apartment;
