const fs = require('fs');

// Lee el archivo JSON
fs.readFile('archivo.json', 'utf8', (err, data) => {
  if (err) {
    console.error('Error al leer el archivo:', err);
    return;
  }

  try {
    // Parsea el contenido del archivo a un arreglo de objetos JavaScript
    const arregloJSON = JSON.parse(data);
    
    // Modifica cada objeto del arreglo según los requisitos
    const arregloModificado = arregloJSON.map(objetoJSON => {
      const objetoModificado = {};

      for (let key in objetoJSON) {
        if (key === "_id" || key === "photos" || key === "status") {
          objetoModificado[key] = objetoJSON[key];
        } else {
          const valor = objetoJSON[key];
          objetoModificado[key] = typeof valor === 'string' ? valor.toUpperCase() : valor;
        }
      }

      return objetoModificado;
    });

    // Convierte el arreglo modificado de vuelta a formato JSON
    const jsonModificado = JSON.stringify(arregloModificado, null, 2);

    // Escribe el JSON modificado en un nuevo archivo
    fs.writeFile('archivo_modificado.json', jsonModificado, 'utf8', (err) => {
      if (err) {
        console.error('Error al escribir el archivo modificado:', err);
        return;
      }
      console.log('Archivo modificado creado con éxito.');
    });

  } catch (error) {
    console.error('Error al parsear el archivo JSON:', error);
  }
});
