import { useState } from "react";
import { useNavigate } from "react-router-dom";
import toast from 'react-hot-toast';
import { useForm,  } from "react-hook-form";
import axios from 'axios';

const apiUrl = import.meta.env.VITE_API_URL;

export const LoginForm = () => {
  const { register, handleSubmit, formState: { errors }, watch } = useForm();
  const navigate = useNavigate();

  const onSubmit = async (formData) => {
    try {
      const response = await axios.post(`${apiUrl}/inicioSesion`, formData, {
        headers: { "Content-Type": "application/json" }
      });
  
      if (!response.data.body.token) {
        throw new Error('Correo o contraseña incorrecta');
      }
  
      const { token, role } = response.data.body;
      toast.success('¡Inicio de sesión exitoso! Redireccionando al dashboard.');
      sessionStorage.setItem('sessionData', JSON.stringify({ token, role }));
      setTimeout(() => navigate(`/${role.toLowerCase()}/Index`), 2500);
  
    } catch (error) {
      handleLoginError(error);
    }
  };
  

  const handleLoginError = (error) => {
    let message = error.message;

    if (error.response) {
      if (error.response.status === 401) {
        message = 'Correo o contraseña incorrecta';
      } else if (error.response.status === 500) {
        message = 'Error interno del servidor. Inténtelo de nuevo más tarde.';
      }
    } else if (error.message.includes('Network Error')) {
      message = 'Error de red al intentar realizar la solicitud. Asegúrate de estar conectado a Internet.';
    }
    
    toast.error(message || 'Ocurrió un error inesperado. Por favor, inténtelo de nuevo más tarde.');
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div className="form-floating mb-3 mt-3">
        <input
          type="text"
          {...register("user_email", {
            required: "Nombre usuario es requerido",
            pattern: {
              message: "Nombre usuario no válido",
            },
          })}
          className="form-control input-text-custom"
          placeholder="name@example.com"
        />
        <label htmlFor="username">Usuario</label>
        {errors.user_email && <span className="text-danger">{errors.user_email.message}</span>}
      </div>
      <div className="form-floating mb-3">
        <input
          type="password"
          {...register("user_password", { required: "Contraseña es requerida" })}
          className="form-control input-text-custom"
          placeholder="name@example.com"
        />
        <label htmlFor="password">Contraseña</label>
        {errors.user_password && <span className="text-danger">{errors.user_password.message}</span>}
      </div>
      <div className="text-center mt-3">
        <button type="submit" className="btn btn-primary fw-bold text-white buton-style">Iniciar sesión</button>
      </div>
    </form>
  );
};
