import { LoginForm } from "./LoginForm"
import "./LoginFormCss.css"
import image from "@assets/ImageInfoLogin.jpg"

export const IndexStyle = () => {

  const StyleContainer = {
    boxShadow: '0px 0px 15px 0px #d2d0d0'
  };
  const StyleContainerPrimary = {
    backgroundColor: "#f3f4f6"
  };
  
  return (
    <>
      <div className="container-fluid  d-flex align-items-center" style={{ height: '100vh' }}>
        {/* <div className="card bg-primarym mx-auto" style={{ width: '60rem' }}> */}
        <div className="row  mx-auto rounded " style={{ width: '60rem', height: '30rem', ...StyleContainer} }>
          <div className="col-4 p-5 rounded-start text-center" style={{...StyleContainerPrimary}}>
            <h3 className=" fw-bold">Iniciar sesión</h3>
            <p className="mt-3 fs-6">Por favor ingresa su informacion personal para ingresar</p>
            <LoginForm/>
          </div>
          <div className="col-8 rounded-end bg-white text-center p-5">
            <img className='w-100 h-100' src={image} alt="" />
          </div>
        </div>
      </div>
      {/* </div> */}

    </>
  )
}