import React, { useEffect, useState } from "react";
import axios from 'axios';
import { useForm } from "react-hook-form";
import toast from 'react-hot-toast';

//IMPORTANTE PARA UTILIZAR EL ENVIROMENT 
const apiUrl = import.meta.env.VITE_API_URL;
const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));

const DashboardRecordAdmin = () => {

  const [apartments, setApartments] = useState([]);
  const [formData, setFormData] = useState([]);
  const {
    register,
    handleSubmit,
    formState: { errors },
    setValue,
    watch,
  } = useForm({
    defaultValues: {
      floor: "",
      room: "",
      request: "",
      damageType: "",
      diagnosis: "",
      image: null,
      responsible: "",
      status: ""
    },
  });

  const status = watch('status');
  useEffect(() =>{
    if(status !== 'completado'){
      setValue("diagnosis", "")
      setValue("responsible", "")

    }
  },[status, setValue])

  const onSubmit = async (data) => {
    console.log("Data before sending to server:", data);
    console.log(formData.responsible + "pepe")
    console.log(watch.diagnosis + "pepe5")
    console.log(formData.diagnosis + "pepe01")
    try {
      const responses = await Promise.all(
        data.map(async (formData) => {
          const formDataToSend = new FormData();
          formDataToSend.append("floor", formData.floor);
          formDataToSend.append("room", formData.room);
          formDataToSend.append("request", formData.request);
          formDataToSend.append("damageType", formData.damageType);
          formDataToSend.append("diagnosis", formData.diagnosis);
          formDataToSend.append("responsible", formData.responsible);
          formDataToSend.append("status", formData.status);
          formDataToSend.append("image", formData.image);
          console.log(formData)
          // Verificar si formData.image no es nulo antes de agregarlo a formDataToSend
          // if (formData.image && formData.image[0]) {
          // }
      

          console.log(formData.diagnosis + "pepe01")
          console.log(formData.image)
          
          return axios.post(`${apiUrl}/reportes/create`, formDataToSend, {
            headers: {
              'Content-Type': 'multipart/form-data',
              Authorization: `Bearer ${datosRecuperados.token}`,
            }
          });
        })
      );

      const successfulResponses = responses.filter(response => response.status === 201);

      if (successfulResponses.length === responses.length) {
        toast.success('Todos los reportes fueron creados correctamente.');
        setApartments([...apartments, ...data]);
        setFormData([]);
      } else {
        toast.error('Algunos reportes no pudieron ser creados.');
      }
    } catch (error) {
      console.log(error);
      toast.error('Error al crear los reportes.');
    }
  };



  const handleDelete = (index) => {
    const newFormData = [...formData];
    newFormData.splice(index, 1);
    setFormData(newFormData);
  };
  const handlePreview = (data) => {
    // Guardar la URL temporalmente en el estado formData si hay una imagen seleccionada
    // console.log(data.image[0])

    if (data.image && data.image[0]) {
      const reader = new FileReader();
      const image1 = data.image[0]
      console.log(image1)
      reader.onload = (e) => {
       
        
        console.log('pepe')
        const newData = { ...data, imageUrl: e.target.result, image: image1};
        // Utilizar una función actualizadora para asegurarse de que se está usando el estado más reciente
        setFormData((prevFormData) => [...prevFormData, newData]);
       

      };
      reader.readAsDataURL(data.image[0]);
    } else {
      // Si no hay imagen seleccionada, simplemente añadir los datos al estado formData
      
      setFormData((prevFormData) => [...prevFormData, data]);
    }
  
    // Limpiar los campos después de agregar los datos
    setValue('floor', '');
    setValue('room', '');
    setValue('request', '');
    setValue('damageType', '');
    setValue('diagnosis', '');
    setValue('responsible', '');
    setValue('status', '');
    setValue('image', null);
  };
  
  const textError = {
    position: 'absolute',
    top: '100%',
    left: 0,
    display: 'block',
    color: 'tomato',
    fontSize: 'x-small',
    paddingBottom: 0,
  };
    
  return (
    <div style={{ width: '100vw', padding: '0 80px 0 10rem' }}>
      {/* <div className="text-center">

        <h1>Registro de reportes</h1>
      </div> */}
      <div className="border p-4 border-rounded mt-2">
        <div className="text-center">

          <h2>Registro de reportes</h2>
        </div>
        <form onSubmit={handleSubmit((data) => handlePreview(data))} className="row g-3">
          <div className="col-md-6">
            <div className="px-5">
              <div className="form-floating mt-4">
                <select
                  className="form-select input-text-custom"
                  {...register("floor", {
                    required: {
                      value: true,
                      message: "Numero de piso",
                    },
                  })}
                >
                  <option value="" disabled>Selecciona el piso</option>
                  <option value="1">Piso 1</option>
                  <option value="2">Piso 2</option>
                  <option value="3">Piso 3</option>
                  <option value="4">Piso 4</option>
                  <option value="5">Piso 5</option>
                  <option value="6">Piso 6</option>
                  <option value="7">Piso 7</option>
                  <option value="8">Piso 8</option>
                  <option value="9">Piso 9</option>
                </select>
                <label>Numero de piso Documento</label>
                {errors.floor?.type === "required" && <span style={textError}>Numero de piso requerido</span>}
              </div>
              <div className="form-floating">
                <input
                  type="text"
                  id="room"
                  name="room"
                  placeholder="room"
                  className="form-control input-text-custom"
                  {...register("room", {
                    required: {
                      value: true,
                      message: "Habitacion es requerida",
                    },
                    pattern: {
                      value: /^[a-zA-Z]?\d+$/,
                      message: "Solo se permiten una letra seguida de números o solo números sin una letra"
                    }
                  })}
                />
                <label>Habitacion</label>
                {errors.room?.type === "required" && <span style={textError}>Habitacion es requerida</span>}
                {errors.room?.type === "pattern" && <span style={textError}>Solo se permiten numeros</span>}
              </div>
              <div className="form-floating">
                <input
                  type="text"
                  id="request"
                  name="request"
                  placeholder="request"
                  className="form-control input-text-custom"
                  {...register("request", {
                    required: {
                      value: true,
                      message: "Numero de solicitud requerido",
                    },
                    pattern: {
                      value: /^[0-9]/,
                      message: "Solo se permiten numeros"
                    }
                  })}
                />
                <label>Numero de solicitud</label>
                {errors.request?.type === "required" && <span style={textError}>Numero de solicitud requerido</span>}
                {errors.request?.type === "pattern" && <span style={textError}>Solo se permiten numeros</span>}
              </div>
              <div className="form-floating ">
                <input
                  type="text"
                  id="damageType"
                  name="damageType"
                  placeholder="Tipo de daño"
                  className="form-control input-text-custom"
                  {...register("damageType", {
                    required: {
                      value: true,
                      message: "Tipo de daño es requerido",
                    },
                  })}
                />
                <label>Tipo de daño</label>
                {errors.damageType?.type === "required" && <span style={textError}>Tipo de daño requerido</span>}
              </div>
            </div>
          </div>
          <div className="col-md-6">
            <div className="px-5">
              <div className="form-floating mt-4">
                <select
                  className="form-select input-text-custom"
                  {...register("status", {
                    required: {
                      value: true,
                      message: "Estado",
                    },
                  })}
                >
                  <option value="" disabled>Selecciona el estado</option>
                  <option value="completado">completado</option>
                  <option value="en curso">En Curso</option>
                  <option value="pendiente">Pendiente</option>
                </select>
                <label>Estado</label>
                {errors.status?.type === "required" && <span style={textError}>Estado requerido</span>}
              </div>
              <div className="form-floating">
                <input
                  type="text"
                  id="diagnosis"
                  name="diagnosis"
                  placeholder="Diagnostico"
                  className="form-control input-text-custom"
                  {...register("diagnosis", {
                    required: watch("status") === "completado" ? "Diagnostico es requerido" : false,
                  })}
                  disabled={watch("status") !== "completado"}
                />
                <label>Diagnostico</label>
                {errors.diagnosis?.type === "required" && <span style={textError}>Diagnostico requerido</span>}
              </div>
              <div className="form-floating">
                <input
                  type="text"
                  id="responsible"
                  name="responsible"
                  placeholder="Responsable"
                  className="form-control input-text-custom"
                  {...register("responsible", {
                    required: watch("status") === "completado" ? "Diagnostico es requerido" : false,
                  })}
                  disabled={watch("status") !== "completado"}
                />
                <label>Responsable</label>
                {errors.responsible?.type === "required" && <span style={textError}>Responsable requerido</span>}
              </div>
              <div className="form-floating mb-3">
                <input
                  type="file"
                  id="image"
                  name="image"
                  className="form-control input-text-custom"
                  {...register("image", {
                    required: watch("status") === "completado" ? "Diagnostico es requerido" : false,
                    validate: {
                      validFileType: (value) => {
                        const acceptedExtensions = ['png', 'jpg', 'jpeg', 'webp'];
                        console.log(value)
                        if (!value || !value[0]) return true; // Si no se selecciona ningún archivo, se considera válido
                        const fileName = value[0].name
                        // Verificar si value no es una cadena
                        const fileExtension = fileName.split('.').pop().toLowerCase();
                        console.log(fileExtension)
                        return acceptedExtensions.includes(fileExtension);
                      }
                    }
                  })}
                  disabled={watch("status") !== "completado"}
                />
                <label className="bg-transparent mb-2">Imagen Reporte</label>
                {errors.image?.type === "required" && <span style={textError}>Imagen requerida</span>}
                {errors.image?.type === "validFileType" && (
                  <span style={textError}>Formato de archivo no válido. Se permiten archivos PNG, JPG, JPEG y WEBP.</span>
                )}
              </div>
            </div>
          </div>
          <div className="text-center mt-2">
            <button type="submit" className="btn btn-primary mt-3 text-white">
              Agregar Reporte
            </button>
          </div>
        </form>

        {formData.length > 0 && (

          <div className="px-5">
            <table class="table table-sm">
              <thead>
                <tr>
                  <th>Piso</th>
                  <th>Habitación</th>
                  <th>Solicitud</th>
                  <th>Tipo de Daño</th>
                  <th>Diagnóstico</th>
                  <th>Responsable</th>
                  <th>Estado</th>
                  <th>Imagen</th>
                  <th>Editar</th>

                </tr>
              </thead>
              <tbody>
                {formData.map((data, index) => (

                  <tr key={index}>

                    <td>{data.floor}</td>
                    <td>{data.room}</td>
                    <td>{data.request}</td>
                    <td>{data.damageType}</td>
                    <td>{data.diagnosis}</td>
                    <td>{data.responsible}</td>


                    <td style={{
                      color: getColorEstado(data.status),
                      marginRight: '5px',
                    }} >{data.status}</td>
                    <td>
                      {/* Mostrar la imagen si hay una URL temporal */}
                      {data.imageUrl && <img src={data.imageUrl} alt="Reporte" style={{ width: '50px', height: '30px' }} />}
                    </td>
                    <td>

                      <button className="btn btn-outline-danger" onClick={() => handleDelete(index)}>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash3" viewBox="0 0 16 16">
                          <path d="M6.5 1h3a.5.5 0 0 1 .5.5v1H6v-1a.5.5 0 0 1 .5-.5M11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3A1.5 1.5 0 0 0 5 1.5v1H1.5a.5.5 0 0 0 0 1h.538l.853 10.66A2 2 0 0 0 4.885 16h6.23a2 2 0 0 0 1.994-1.84l.853-10.66h.538a.5.5 0 0 0 0-1zm1.958 1-.846 10.58a1 1 0 0 1-.997.92h-6.23a1 1 0 0 1-.997-.92L3.042 3.5zm-7.487 1a.5.5 0 0 1 .528.47l.5 8.5a.5.5 0 0 1-.998.06L5 5.03a.5.5 0 0 1 .47-.53Zm5.058 0a.5.5 0 0 1 .47.53l-.5 8.5a.5.5 0 1 1-.998-.06l.5-8.5a.5.5 0 0 1 .528-.47M8 4.5a.5.5 0 0 1 .5.5v8.5a.5.5 0 0 1-1 0V5a.5.5 0 0 1 .5-.5" />
                        </svg>
                      </button>
                    </td>
                  </tr>
                ))}

              </tbody>
            </table>
          </div>
        )}
        <div className="text-center mt-2 px-2">
          {formData.length > 0 && (
            <>
              <button className="btn btn-danger mt-3 text-white me-2" onClick={() => { handlePreview(null); setFormData([]); }}>Cancelar</button>
              <button onClick={() => {
                onSubmit(formData);
                setFormData([]);
              }} className="btn btn-primary mt-3 text-white">
                Enviar Reportes
              </button>
            </>
          )}
        </div>

      </div>
    </div>
  );
};

export default DashboardRecordAdmin;


function getColorEstado(estado) {
  switch (estado) {
    case 'pendiente':
      return 'orange';
    case 'en curso':
      return 'blue';
    case 'completado':
      return 'green';
    default:
      return 'black';
  }
}