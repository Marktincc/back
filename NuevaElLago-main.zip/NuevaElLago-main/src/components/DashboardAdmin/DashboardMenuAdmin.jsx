import { NavLink } from 'react-router-dom';
import { useNavigate, Outlet } from "react-router-dom";
import './DashboardMenuCss.css'
import cnelLogo from '@assets/Isologo CNEL-PNG.png'

//IMPORTANTE PARA UTILIZAR EL ENVIROMENT 
const apiUrl = import.meta.env.VITE_API_URL;
const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));

export const DashboardMenuAdmin = () => {
  const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));
  const name = "Juan Pepe"
  const namearray = name.split(' ');
  const firstName = namearray[0];
  const secondName = namearray[1];

  const navigate = useNavigate();
  const sessionExit = () => {
    // Clear sessionStorage
    sessionStorage.clear();
    // navigate('/');


  }
  const userTittleStyle = {
    fontSize: '25px'
  }
  return (
    <>
      <div className='w-100'>
        {/* <div style={{ overflow: 'hidden' }}>
          <svg
            preserveAspectRatio="none"
            viewBox="0 0 1200 120"
            xmlns="http://www.w3.org/2000/svg"
            style={{ fill: '#ffffff', width: '125%', height: '345px', transform: 'rotate(180deg) scaleX(-1)' }}
          >
            <path d="M321.39 56.44c58-10.79 114.16-30.13 172-41.86 82.39-16.72 168.19-17.73 250.45-.39C823.78 31 906.67 72 985.66 92.83c70.05 18.48 146.53 26.09 214.34 3V0H0v27.35a600.21 600.21 0 00321.39 29.09z" />
          </svg>
        </div> */}
        <Outlet />

      </div>
      <div className="style-menu bg-dark dashboard-style h-100 pe-0 ps-0">
        <div>

          <ul className="nav nav-pills nav-flush flex-column">
            <li className="nav-item text-white nav-link mt-2">
              <img src={cnelLogo} alt="" width={187} height={46} />


            </li>
          </ul>
        </div>
        <hr className="featurette-divider text-white" />
        <div>
          <ul className="nav nav-pills nav-flush flex-column h-100">
            <li className="nav-item text-white">
              {/* <a href="#" className="nav-link active mb-3 pt-2"> */}
              <NavLink className={({ isActive }) => (isActive ? 'nav-link mb-3 text-white active ms-2' : "ms-2 nav-link mb-3 text-white")} to='/admin/index'>
                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-clipboard-data" viewBox="0 0 16 16">
                  <path d="M4 11a1 1 0 1 1 2 0v1a1 1 0 1 1-2 0zm6-4a1 1 0 1 1 2 0v5a1 1 0 1 1-2 0zM7 9a1 1 0 0 1 2 0v3a1 1 0 1 1-2 0z" />
                  <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1z" />
                  <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0z" />
                </svg>
                <h5 className="ver  px-2 mb-0">Informe</h5>
                <h5 className="ver  me-2 mb-0">de</h5>
                <h5 className="ver mb-0">timbres</h5>
              </NavLink>
              {/* </a> */}
            </li>
            <li className="nav-item text-white">
              {/* <a href="#" className="nav-link text-white mb-3 pt-2"> */}
              <NavLink className={({ isActive }) => (isActive ? 'nav-link mb-3 text-white active ms-2' : "nav-link mb-3 text-white ms-2")} to='/admin/dooberlls'>
                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16">
                  <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2z" />
                  <path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5m-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0M7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5m-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0" />
                </svg>
                <h5 className="ver  px-2 mb-0">Reporte</h5>
                <h5 className="ver  me-2 mb-0">de</h5>
                <h5 className="ver mb-0">timbres</h5>

                {/* </a> */}
              </NavLink>
            </li>
            <li className="nav-item text-white">
              <NavLink className={({ isActive }) => (isActive ? 'nav-link mb-3 text-white active ms-2' : "nav-link mb-3 text-white ms-2")} to='/admin/record'>
                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-file-earmark-plus" viewBox="0 0 16 16">
                  <path d="M8 6.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V11a.5.5 0 0 1-1 0V9.5H6a.5.5 0 0 1 0-1h1.5V7a.5.5 0 0 1 .5-.5" />
                  <path d="M14 4.5V14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2h5.5zm-3 0A1.5 1.5 0 0 1 9.5 3V1H4a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V4.5z" />
                </svg>
                <h5 className="ver  px-2 mb-0">Registrar</h5>
                <h5 className="ver  me-2 mb-0">reportes</h5>


                {/* </a> */}
              </NavLink>
            </li>
            
            <hr className="text-white" />
            <li className="nav-item text-white mt-auto">
              <NavLink onClick={sessionExit} className={({ isActive }) => (isActive ? 'nav-link mb-3 text-white active ms-2' : "nav-link mb-3 text-white ms-2")} to='/'>

                <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" className="bi bi-box-arrow-left" viewBox="0 0 16 16">
                  <path fillRule="evenodd" d="M6 12.5a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v2a.5.5 0 0 1-1 0v-2A1.5 1.5 0 0 1 6.5 2h8A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 5 12.5v-2a.5.5 0 0 1 1 0z" />
                  <path fillRule="evenodd" d="M.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L1.707 7.5H10.5a.5.5 0 0 1 0 1H1.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3z" />
                </svg>
                <h5 className="ver px-2 mb-0">Cerrar</h5>
                <h5 className="ver mb-0">sesión</h5>
              </NavLink>
            </li>
          </ul>
        </div>
      </div>
    </>
  );

}