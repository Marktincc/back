// DashboardDooberllsAdmin.jsx
import React, { useState, useEffect } from 'react';
import { DataGrid } from '@mui/x-data-grid';
import { esES } from '@mui/x-data-grid/locales';
import axios from 'axios';
import './DashboardDooberllsAdminCss.css';
import Modal from './DashboardDooberllsAdminModal';
import ImageModal from './DashboardDooberllsAdminModalImage';
import ReportModal from './DashboardDooberllsAdminModalInfoTimbre';
//IMPORTANTE PARA UTILIZAR EL ENVIROMENT 
const apiUrl = import.meta.env.VITE_API_URL;
const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));


export const DashboardDooberllsAdmin = () => {
  const [data, setData] = useState([]);
  const [selectedReportId, setSelectedReportId] = useState(null);
  const [modalOpen, setModalOpen] = useState(true);
  const [modalImageUrl, setModalImageUrl] = useState(true);
  const [modalReport, setModalReport] = useState(true);
  const fetchData = async () => {
    try {
      const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));

      const response = await axios.get(`${apiUrl}/reportes/allReports`, {
        headers: {
          Authorization: `Bearer ${datosRecuperados.token}`
        }
      });
      const formattedData = response.data.body.map(item => ({
        ...item,
        createdAt: new Date(item.createdAt),
        completionDate: new Date(item.completionDate),

      }));
      formattedData.sort((a, b) => b.createdAt - a.createdAt);
      setData(formattedData);
      console.log(formattedData);
    } catch (error) {
      console.error('Error al obtener los datos:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);
  const updateTableData = async () => {
    try {
      await fetchData(); // Llama a fetchData para obtener los datos actualizados
    } catch (error) {
      console.error('Error al actualizar los datos de la tabla:', error);
    }
  };


  const handleEdit = (reportId) => {
    console.log('Editando reporte con ID:', reportId);
    setSelectedReportId(reportId);
    setModalOpen(true);
    console.log(modalOpen)
    // document.getElementById('exampleModal').classList.add('show');
  };

  const handleCloseModal = () => {
    setModalOpen(false);
  };
  const handleOpenModal = (imageUrl) => {
    console.log(imageUrl);
    setModalImageUrl(imageUrl);
  };
  const getRowClassName = (params) => {
    switch (params.row.status) {
      case 'pendiente':
        return 'fila-pendiente';
      case 'en curso':
        return 'fila-en-curso';
      case 'completado':
        return 'fila-completado';
      default:
        return '';
    }
  };

  const containerStyle = {
    width: '100vw',
    padding: '0 80px 0 10rem'
  };


  const columns = [
    { field: '_id', headerName: 'ID', width: 10, },
    { field: 'floor', headerName: 'Piso', width: 10, valueOptions: Array.from({ length: 9 }, (_, i) => ({ label: (i + 1).toString(), value: (i + 1).toString() })) },
    { field: 'room', headerName: 'Habitación', },
    { field: 'request', headerName: 'Solicitud' },
    { field: 'damageType', headerName: 'Tipo de daño', width: 120, },
    { field: 'responsible', headerName: 'Responsable' },
    { field: 'diagnosis', headerName: 'Diagnóstico', width: 120, },
    {
      field: 'status', headerName: 'Estado', renderCell: (params) => (
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <div
            style={{
              color: getColorEstado(params.value),
              marginRight: '5px',
            }}
          >
            {params.value}
          </div>
        </div>
      ),
      valueOptions: ['pendiente', 'en curso', 'completado'].map(value => ({ value, label: value.charAt(0).toUpperCase() + value.slice(1) })),
    },
    { field: 'createdAt', headerName: 'Fecha de creación', minWidth: 120, type: 'date' },
    { field: 'completionDate', headerName: 'Fecha de Reparacion', minWidth: 120, type: 'date' },
    {
      field: 'image',
      headerName: 'Imagen',
      renderCell: (params) => (
        <div onMouseEnter={(e) => { e.target.style.transform = 'scale(1.5)'; }} onMouseLeave={(e) => { e.target.style.transform = 'scale(1)'; }}>
          {params.row.photos && params.row.photos.length > 0 && (
            // <img src={`${apiUrl}/imagenes/${params.row.photos[0]}`} className='rounded-circle' alt="imagen" style={{ width: '50px', height: '50px', transition: 'transform 0.3s ease-in-out' }} />
            <img
              src={`${apiUrl}/imagenes/${params.row.photos[0]}`}
              alt="imagen"
              onClick={() => handleOpenModal(`${apiUrl}/imagenes/${params.row.photos[0]}`)} // Abre el modal al hacer clic en la imagen
              data-bs-target="#exampleModal1"
              data-bs-toggle="modal"
              style={{ width: '50px', height: '50px', transition: 'transform 0.3s ease-in-out' }}
            />
          )}
        </div>
      ),
    },
    {
      field: 'edit',
      headerName: 'Editar',
      sortable: false,
      renderCell: (params) => (
        <button className='btn text-primary ' data-bs-toggle="modal"
          style={{
            transition: 'transform 0.3s ease', /* Agrega una transición suave a la propiedad transform */
          }}
          onMouseOver={(e) => { e.target.style.transform = 'scale(1.1)'; }} /* Agranda el botón al 110% del tamaño original cuando el cursor está sobre él */
          onMouseOut={(e) => { e.target.style.transform = 'scale(1)'; }} /* Restaura el tamaño original cuando el cursor sale del botón */
          data-bs-target="#exampleModal" onClick={() => handleEdit(params.row._id)}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
            <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
            <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z" />
          </svg></button>
      ),
    },
    {
      field: 'details',
      headerName: 'Detalles',
      sortable: false,
      renderCell: (params) => (
        <button className='btn text-primary ' data-bs-toggle="modal"
          style={{
            transition: 'transform 0.3s ease', /* Agrega una transición suave a la propiedad transform */
          }}
          onMouseOver={(e) => { e.target.style.transform = 'scale(1.1)'; }} /* Agranda el botón al 110% del tamaño original cuando el cursor está sobre él */
          onMouseOut={(e) => { e.target.style.transform = 'scale(1)'; }} /* Restaura el tamaño original cuando el cursor sale del botón */
          data-bs-target="#exampleModal2" onClick={() => handleRowSelection(params.row._id)}><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-card-checklist" viewBox="0 0 16 16">
          <path d="M14.5 3a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-9a.5.5 0 0 1 .5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2z"/>
          <path d="M7 5.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5m-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 1 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0M7 9.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5m-1.496-.854a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0l-.5-.5a.5.5 0 0 1 .708-.708l.146.147 1.146-1.147a.5.5 0 0 1 .708 0"/>
        </svg></button>
      ),
    },
  ];
  const handleRowSelection = (params) => {
    const reportId = params
    console.log(reportId);
    setModalReport(reportId);
    setModalOpen(true); // Abre el modal al seleccionar una fila
  };
  const openModal = () => {
    setModalOpen(true);
  };
  const defaultPageSize = 10;
  const pageSizeOptions = [5, 10, 20, 50];
  return (
    <div className='' style={containerStyle}>
      <h4 className='mb-3 text-center'>Reportes de timbres</h4>
      <DataGrid
        rows={data}
        columns={columns}
        columnVisibilityModel={{
          // Hide columns status and traderName, the other columns will remain visible
          _id: false,
        }}
        autoHeight
        getRowId={(row) => row._id}
        getRowClassName={getRowClassName}
        initialState={{
          ...data.initialState,
          pagination: { paginationModel: { pageSize: 10 } },
        }}
        pageSizeOptions={[ 10, 15,20, 25,100]}
        localeText={esES.components.MuiDataGrid.defaultProps.localeText}
      />
      {modalOpen && (
        <Modal
          handleClose={handleCloseModal}
          reportId={selectedReportId}
          updateTableData={updateTableData}
          setModalOpen={setModalOpen}
        />
      )}
      {modalImageUrl && (
        <ImageModal imageUrl={modalImageUrl} handleClose={handleCloseModal} />
      )}
       {modalReport && (
        <ReportModal reportId={modalReport} handleClose={handleCloseModal} />
      )}
    </div>
  
  );
};

function obtenerURLImagen(nombreImagen) {
  const baseUrl = `${apiUrl}/imagenes/`;
  return baseUrl + nombreImagen;
}


function getColorEstado(estado) {
  switch (estado) {
    case 'pendiente':
      return 'orange';
    case 'en curso':
      return 'blue';
    case 'completado':
      return 'green';
    default:
      return 'black';
  }
}