import React from 'react';

const ImageModal = ({ imageUrl, handleClose }) => {
  return (
    <div>

      <div className="modal fade" id="exampleModal1" tabIndex="-1" aria-labelledby="staticBackdropLabel" >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="staticBackdropLabel">Foto del reporte del timbre</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" ></button>
            </div>
            <div className="modal-body">
              {/* Renderizar el formulario correspondiente */}

              <img src={imageUrl} alt="imagen" className='w-100 h-75' />
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
              {/* Agrega aquí cualquier botón adicional o lógica según sea necesario */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageModal;
