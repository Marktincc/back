import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useForm } from "react-hook-form";
import toast from 'react-hot-toast';
import "./DashboardAdminFormCss.css"

//IMPORTANTE PARA UTILIZAR EL ENVIROMENT 
const apiUrl = import.meta.env.VITE_API_URL;
const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));

const DashboardDooberllsAdminModal = ({ handleClose, reportId, updateTableData, setModalOpen }) => {
  const [processComplet, setProcessComplet] = useState(false);
  ///////////////////// PROCESS COMPLETE //////////////////////
  const {
    register,
    handleSubmit,
    formState: { errors },
    watch,
    setValue,
  } = useForm({
    defaultValues: {
      responsible: "",
      diagnosis: "",
      image: [0]
    },
  });
  const textError = {
    position: 'absolute',
    top: '100%',
    left: 0,
    display: 'block',
    color: 'tomato',
    fontSize: 'x-small',
    paddingBottom: 0,
  };
  const onSubmit = async (data) => {
    // Use data to send the product information
    console.log(data);
    try {
      const formData = new FormData();
      formData.append("responsible", data.responsible);
      formData.append("diagnosis", data.diagnosis);
      formData.append("image", data.image[0]);
      console.log(formData);

      const response = await axios.post(`${apiUrl}/reportes/${reportId}/completeReport`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          Authorization: `Bearer ${datosRecuperados.token}`
        }
      });

      if (response.status === 200) {
        console.log("Reporte terminado correctamente");
        setProcessComplet(!processComplet);
        toast.success('Reporte terminado correctamente.');
        setValue('responsible', '');
        setValue('diagnosis', '');
        setValue('image', [0]);
        updateTableData();
        setModalOpen(false)
        const modalBackdrop = document.querySelector('.modal-backdrop');
        modalBackdrop.parentNode.removeChild(modalBackdrop);

      } else {
        console.log("Error al crear el Reporte");
        toast.error('Error al crear el Reporte');
      }
    } catch (error) {
      console.log(error);
    }
  };
  const onSubmitInProgress = async (data) => {
    // Use data to send the product information
    console.log(data);
    try {
      const data = {
        newStatus: 'en curso'
      };
      console.log(data);

      const response = await axios.put(`${apiUrl}/reportes/updateStatus/${reportId}`, data, {
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${datosRecuperados.token}`
        }
      });

      if (response.status === 200) {
        console.log("Reporte en curso correctamente");
        setProcessComplet(!processComplet);
        toast.success('Reporte en curso correctamente.');
        setReportStatus('en curso');
        // handleCloseModal();
        updateTableData();
        setModalOpen(false)
        const modalBackdrop = document.querySelector('.modal-backdrop');
        modalBackdrop.parentNode.removeChild(modalBackdrop);
      } else {
        console.log("Error al crear el Reporte");
        toast.error('Error al crear el Reporte');
      }
    } catch (error) {
      console.log(error);
    }
  };



  const [reportStatus, setReportStatus] = useState('');

  useEffect(() => {
    // Hacer la solicitud al servidor para obtener el estado del informe
    const fetchReportStatus = async () => {
      try {
        const response = await axios.get(`${apiUrl}/reportes/${reportId}/status`, {
          headers: {
            Authorization: `Bearer ${datosRecuperados.token}`
          }
        });
        setReportStatus(response.data.body.status);
      } catch (error) {
        console.error('Error al obtener el estado del informe:', error);
      }
    };

    fetchReportStatus();
  }, [reportId]);

  // Renderizar el formulario correspondiente según el estado del informe
  const renderForm = () => {
    switch (reportStatus) {
      case 'pendiente':
        return <PendingForm />;
      case 'en curso':
        return <InProgressForm />;
      case 'completado':
        return <CompletedForm />;
      default:
        return <p>No se pudo obtener el estado del informe.</p>;
    }
  };
  const [selectedState, setSelectedState] = useState(""); // Estado para almacenar la opción seleccionada del select

  // Manejar cambio de selección en el select
  const handleStateChange = (event) => {
    setSelectedState(event.target.value);
  };
  // Componentes de formulario para diferentes estados
  const renderFields = () => {
    if (selectedState === "terminado") {
      return (
        <div>
          <form onSubmit={handleSubmit(onSubmit)}>
            {/* Personal Information */}
            <div className="px-5">
              <div className="">
                <div className="form-floating">
                  <input
                    type="text"
                    id="diagnosis"
                    name="diagnosis"
                    placeholder="Diagnostico"
                    className="form-control input-text-custom"
                    // onChange={handleChange}
                    {...register("diagnosis", {
                      required: {
                        value: true,
                        message: "Diagnostico es requerido",
                      },
                    })}
                  />
                  <label>Diagnostico</label>
                  {errors.diagnosis?.type === "required" && <span style={textError}>Diagnostico requerido</span>}

                </div>
              </div>
              <div className="">
                <div className="form-floating mb-3">
                  <input
                    className="form-control input-text-custom"
                    id="responsible"
                    name="responsible"
                    {...register("responsible", {
                      required: {
                        value: true,
                        message: "Responsable es requerido",
                      },
                    })}
                  />
                  <label>Responsable es requerido</label>
                  {errors.responsible?.type === "required" && <span style={textError}>Responsable es requerido</span>}

                </div>
              </div>
            </div>
            <div className="">
              <div className="px-5">
                <div className="form-floating">
                  <input
                    type="file"
                    id="image"
                    name="image"
                    // onChange={handleChange}
                    className="form-control input-text-custom"
                    {...register("image", {
                      required: {
                        value: true,
                        message: "Imagen es requerida",
                      },
                    })}
                  />
                  <label className="bg-transparent">Imagen Reporte</label>
                  {errors.image?.type === "required" && <span style={textError}>Imagen requerida</span>}
                </div>
              </div>
            </div>

            <div className="text-center mt-2">
              <button type="submit" className="btn btn-primary mt-3 text-white">
                Enviar Reporte
              </button>
            </div>
          </form>
        </div>
      );
    } else if (selectedState === "en_curso") {
      return (
        <div>
          <form onSubmit={handleSubmit(onSubmitInProgress)}>
            {/* Add a submit button */}
            <div className="text-center mt-2">
              <button type="submit" className="btn btn-primary mt-3 text-white">
                Actualizar estado a en proceso
              </button>
            </div>
          </form>
        </div>
      );
    } else {
      return null; // No mostrar ningún campo si no se ha seleccionado ningún estado
    }
  };

  const PendingForm = () => {
    return (
      <div>
        <h4>Formulario para informes pendientes</h4>
        <select value={selectedState} onChange={handleStateChange} className="form-select mb-3">
          <option value="">Seleccione el estado</option>
          <option value="terminado">Terminado</option>
          <option value="en_curso">En Curso</option>
        </select>
        {renderFields()}
        {/* Agrega aquí los campos del formulario para informes pendientes */}

      </div>
    );
  };

  const InProgressForm = () => {
    return (
      <div>
        <h4>Formulario para informes en curso</h4>
        <form onSubmit={handleSubmit(onSubmit)}>
          {/* Personal Information */}
          <div className="px-5">
            <div className="">
              <div className="form-floating mb-3">
                <input
                  type="text"
                  className="form-control input-text-custom"
                  id="diagnosis"
                  name="diagnosis"
                  placeholder="Descripción del Reporte"

                  {...register("diagnosis", {
                    required: {
                      value: true,
                      message: "Diagnostico es requerido",
                    },
                  })}
                />
                <label>Diagnostico</label>
                {errors.diagnosis?.type === "required" && <span style={textError}>Diagnostico requerido</span>}
              </div>
            </div>
            <div className="">
              <div className="form-floating mb-3">
                <input
                  type='text'
                  id="responsible"
                  name="responsible"
                  placeholder="Descripción del Reporte"
                  className="form-control input-text-custom"
                  {...register("responsible", {
                    required: {
                      value: true,
                      message: "Responsable es requerido",
                    },
                  })}
                />
                <label>Responsable es requerido</label>
                {errors.responsible?.type === "required" && <span style={textError}>Responsable es requerido</span>}

              </div>
            </div>
          </div>
          <div className="">
            <div className="px-5">
              <div className="form-floating">
                <input
                  type="file"
                  className="form-control input-text-custom"
                  {...register("image", {
                    required: {
                      value: true,
                      message: "Imagen es requerida",
                    },
                    validate: {
                      validFileType: (value) => {
                        const acceptedExtensions = ['png', 'jpg', 'jpeg', 'webp'];
                        console.log(value)
                        if (!value || !value[0]) return true; // Si no se selecciona ningún archivo, se considera válido
                        const fileName = value[0].name
                        // Verificar si value no es una cadena
                        const fileExtension = fileName.split('.').pop().toLowerCase();
                        console.log(fileExtension)
                        return acceptedExtensions.includes(fileExtension);
                      }
                    }
                  })}
                />
                <label className="bg-transparent">Imagen Reporte</label>
                {errors.image?.type === "required" && <span style={textError}>Imagen requerida</span>}
                {errors.image?.type === "validFileType" && (
                  <span style={textError}>Formato de archivo no válido. Se permiten archivos PNG, JPG, JPEG y WEBP.</span>
                )}
              </div>
            </div>
          </div>
          <div className="text-center mt-2">
            <button type="submit" className="btn btn-primary text-white mt-3">
              Enviar Reporte
            </button>
          </div>
        </form>
      </div>
    );
  };

  const CompletedForm = () => {
    return (
      <div>
        <h4>Formulario para informes completados</h4>
        <p>Este reporte ya asido cerrado</p>
        {/* Agrega aquí los campos del formulario para informes completados */}
      </div>
    );
  };

  return (
    <div>

      <div className="modal fade" id="exampleModal" tabIndex="-1" aria-labelledby="staticBackdropLabel" >
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="staticBackdropLabel">Editar Estado</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" ></button>
            </div>
            <div className="modal-body">
              {/* Renderizar el formulario correspondiente */}
              {renderForm()}
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
              {/* Agrega aquí cualquier botón adicional o lógica según sea necesario */}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardDooberllsAdminModal;