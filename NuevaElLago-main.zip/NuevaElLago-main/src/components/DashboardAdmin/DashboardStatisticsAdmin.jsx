import React, { useState, useEffect, useRef } from 'react';
import Chart, { Ticks } from 'chart.js/auto';
import axios from 'axios';
import randomColor from 'randomcolor';
import * as XLSX from 'xlsx';
import { callback, color } from 'chart.js/helpers';

//IMPORTANTE PARA UTILIZAR EL ENVIROMENT 
const apiUrl = import.meta.env.VITE_API_URL;
const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));


const DamageByRoomChart = ({ chartData }) => {
  const chartRef = useRef(null);

  useEffect(() => {
    if (chartRef.current && chartData.length > 0) {
      const ctx = chartRef.current.getContext('2d');
      const chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: chartData.map((item) => `Piso ${item.floor}, Habitación ${item.room}`),
          datasets: [
            {
              label: 'Daño por habitación',
              data: chartData.map((item) => item.damage),
              backgroundColor: chartData.map((item) => item.color),
            },
          ],
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'top',
            },
            title: {
              display: true,


            },

          },
          scales: {
            y: {
              beginAtZero: true,
              title: {
                display: true,
                text: '',

              },
              ticks: {
                callback: function (value, index, values) {
                  return ('Numero de reportes  ' + value)
                },
                stepSize: 1
              }
            }
          },
        },

      });

      return () => {
        chart.destroy();
      };
    }
  }, [chartData]);

  return <canvas ref={chartRef} />;
};

const ReportsByMonthChart = ({ reportsByMonthData }) => {
  const chartRef = useRef(null);

  useEffect(() => {
    if (chartRef.current && reportsByMonthData.length > 0) {
      const ctx = chartRef.current.getContext('2d');
      const monthNames = [
        'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
        'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
      ];

      const chart = new Chart(ctx, {
        type: 'bar',
        data: {
          labels: reportsByMonthData.map((item) => monthNames[item._id - 1]), // Convertir números de meses a nombres de meses
          datasets: [
            {
              label: 'Numero de reportes por mes',
              data: reportsByMonthData.map((item) => item.count),
              backgroundColor: 'rgba(75, 192, 192, 0.2)',
              borderColor: 'rgba(75, 192, 192, 1)',
              borderWidth: 1,
              scales: {
                y: {
                  beginAtZero: true,
                  title: {
                    display: true,
                    text: 'dsaa',
                    font: {
                      size: 20
                    }
                  },
                }
              },
            },
          ],
        },
        options: {
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });

      return () => {
        chart.destroy();
      };
    }
  }, [reportsByMonthData]);

  return <canvas ref={chartRef} />;
};
export const DashboardStatisticsAdmin = () => {
  const [totalDamageData, setTotalDamageData] = useState([]);
  const [totalDamageData1, setTotalDamageData1] = useState([]);

  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedFloor, setSelectedFloor] = useState(1);
  const [chartData, setChartData] = useState([]);
  const [chartDataSelectedFloor, setChartDataSelectedFloor] = useState([]);
  const [chartDataMonth, setChartDataMonth] = useState([]);


  const [reportsByMonthData, setReportsByMonthData] = useState([]);
  const [yearInput1, setYearInput1] = useState(new Date().getFullYear().toString());
  const handleYearInputChange1 = (event) => {
    setYearInput1(event.target.value);
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));
        const response = await axios.get(`${apiUrl}/reportes/damagedRoomsByFloor`, {
          headers: {
            Authorization: `Bearer ${datosRecuperados.token}`
          }
        });
        if (response.status === 200) {
          const roomDamage = response.data.body.map((item) => ({
            room: item._id.room,
            floor: item._id.floor,
            damage: item.totalDamage,
            color: randomColor(),
          }));
          setTotalDamageData1(roomDamage);
        } else {
          throw new Error('Error al obtener los datos');
        }
      } catch (error) {
        console.error('Error fetching data:', error.message);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));
        const response = await axios.get(`${apiUrl}/reportes/getDamagedRoomsByYear/${yearInput1}`, {
          headers: {
            Authorization: `Bearer ${datosRecuperados.token}`
          }
        });
        if (response.status === 200) {
          const roomDamage = response.data.body.map((item) => ({
            room: item._id.room,
            floor: item._id.floor,
            damage: item.totalDamage,
            color: randomColor(),
          }));
          setTotalDamageData(roomDamage);
          setChartData(roomDamage);
        } else {
          throw new Error('Error al obtener los datos');
        }
      } catch (error) {
        console.error('Error fetching data:', error.message);
      }
    };

    fetchData();
  }, [yearInput1]);
  const [yearInput, setYearInput] = useState(new Date().getFullYear().toString());
  const handleYearInputChange = (event) => {
    setYearInput(event.target.value);
  };


  const [currentMonth, setCurrentMonth] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));
        const response = await axios.get(`${apiUrl}/reportes/reportsByMonth/${yearInput}`, {
          headers: {
            Authorization: `Bearer ${datosRecuperados.token}`
          }
        });
        if (response.status === 200) {
          const reportsByMonth = response.data.body;
          setReportsByMonthData(reportsByMonth);
        } else {
          throw new Error('Error al obtener los datos de los informes por mes');
        }
      } catch (error) {
        console.error('Error fetching reports by month data:', error.message);
      }
    };

    fetchData();
  }, [yearInput]); // Asegúrate de incluir yearInput como dependencia para que se ejecute cada vez que cambie
  useEffect(() => {
    const monthNames = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
      'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
    ];
    const date = new Date();
    const currentMonthNumber = date.getMonth() + 1; // El mes en JavaScript es de 0 a 11, agregamos 1 para que sea de 1 a 12
    const currentMonthName = monthNames[currentMonthNumber - 1]; // Restamos 1 para acceder al índice correcto del array
    setCurrentMonth(currentMonthName);
  }, []);

  const currentDate = new Date();
  const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  const lastDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);

  const [startDate, setStartDate] = useState(firstDayOfMonth);
  const [endDate, setEndDate] = useState(lastDayOfMonth);

  useEffect(() => {
    // setSelectedFloor(1); // Establecer el piso seleccionado en 1 al principio
    handleButtonClick(); // Cargar datos del piso 1
  }, [selectedFloor, startDate, endDate]);


  const handleButtonClick = async () => {
    try {
    
      const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));
      const response = await axios.get(`${apiUrl}/reportes/damagedRoomsByFloor/${selectedFloor}`, {
        params: {
          startDate: startDate.toISOString().slice(0, 10),
          endDate: endDate.toISOString().slice(0, 10),
        },
        headers: {
          Authorization: `Bearer ${datosRecuperados.token}`
        }
      });
      if (response.status === 200) {
        const roomDamage = response.data.body.map((item) => ({
          room: item._id.room,
          floor: item._id.floor,
          damage: item.totalDamage,
          color: randomColor(),
          
        }));
       
        setChartDataSelectedFloor(roomDamage);
      } else {
        throw new Error('Error al obtener los datos de la habitación seleccionada');
      }
    } catch (error) {
      console.error('Error fetching room damage data:', error.message);
    }
  };
  
  const handleShowAllButtonClick = () => {
    setChartData(totalDamageData);
  };

  const [selectedStartDate, setSelectedStartDate] = useState(firstDayOfMonth);
  const [selectedEndDate, setSelectedEndDate] = useState(lastDayOfMonth);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));
        const startDate1 = selectedStartDate.toISOString().slice(0, 10); // Convertir fecha de inicio a formato ISO
        const endDate1 = selectedEndDate.toISOString().slice(0, 10); // Convertir fecha de fin a formato ISO
        const response = await axios.get(`${apiUrl}/reportes/getDamagedRoomsByDateRange/${startDate1}/${endDate1}`, {
          headers: {
            Authorization: `Bearer ${datosRecuperados.token}`
          }
        });
        if (response.status === 200) {
          const roomDamage = response.data.body.map((item) => ({
            room: `${item._id.room}`,
            floor: item._id.floor,
            damage: item.totalDamage,
            color: randomColor(),
          }));
          setChartDataMonth(roomDamage);
        } else {
          throw new Error('Error al obtener los datos');
        }
      } catch (error) {
        console.error('Error fetching data:', error.message);
      }
    };

    fetchData();
  }, [selectedStartDate, selectedEndDate]);


  const handleExportButtonClick = () => {
    if (chartData.length > 0) {
      const workbook = XLSX.utils.book_new();
      const worksheet = XLSX.utils.json_to_sheet(chartData);

      XLSX.utils.book_append_sheet(workbook, worksheet, 'ChartData');
      XLSX.writeFile(workbook, 'chart_data.xlsx');
    }
  };

  const uniqueFloors = [...new Set(totalDamageData1.map((item) => item.floor))];
  const sortedFloors = [...uniqueFloors].sort((a, b) => a - b);

  const botonStyle = {
    height: '5rem'
  };
  const chartIdStyle = {
    width: '25rem',

  };
  const containerStyle = {
    width: '100vw',
    padding: '0 80px 0 10rem'
  };

  const [reportCounts, setReportCounts] = useState({
    "error": "",
    "body": {
      "en curso": 0,
      "completado": 0,
      "pendiente": 0
    }
  });
  useEffect(() => {
    // Realiza la solicitud GET al cargar el componente
    const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));
    axios.get(`${apiUrl}/reportes/statusCounts`, {
      headers: {
        Authorization: `Bearer ${datosRecuperados.token}`
      }
    })
      .then(response => {
        // Actualiza el estado con los datos recibidos
        const data = {
          "body": {
            "en curso": response.data.body?.["en curso"] || 0,
            "completado": response.data.body?.["completado"] || 0,
            "pendiente": response.data.body?.["pendiente"] || 0,
          }
        };
        console.log(response.data)
        setReportCounts(data);
      })
      .catch(error => {
        console.error('Error al obtener los datos de estado de los informes:', error);
      });
  }, []);
  useEffect(() => {
    handleButtonClick();
  }, [selectedFloor]);
  return (
    <div className="dashboard-statistics" style={containerStyle}>

      <div className="container-fluid" style={{ background: "none" }}>
        <h1 className='text-center'>Informe general de timbres
        </h1>
        <div className="row" style={{ padding: '10px' }}>
          <div className="col bg-danger rounded p-2 ps-4 mb-0 mx-1" style={{ ...botonStyle }}>
            <p>Pendiente</p>
            <h4>{reportCounts.body.pendiente}</h4>
          </div>
          <div className="col  rounded p-2 ps-4 mb-0 mx-1" style={{ ...botonStyle, backgroundColor: "#ffa500" }}>
            <p>En proceso</p>
            <h4>{reportCounts.body['en curso']}</h4>
          </div>
          <div className="col rounded p-2 ps-4 mx-1" style={{ ...botonStyle, backgroundColor: "#a5c435" }}>
            <p>Completado</p>
            <h4>{reportCounts.body.completado}</h4>
          </div>
        </div>

      </div>
      <div className="container text-center ">
        <div style={{ border: '1px solid #ccc', borderRadius: '5px', padding: '10px', marginBottom: '20px' }} >
          <h3 className='text-start' style={{ textAlign: 'center', marginBottom: '10px' }}>Gráfico de reportes de timbres por año</h3>
          <div className="form-floating ">
            <input
              type="number"
              className="form-control input-text-custom w-25"
              value={yearInput1}
              onChange={handleYearInputChange1}
              placeholder="Ingresa el año"
              min="2000" // Año mínimo permitido
              max={new Date().getFullYear()} // Año máximo permitido
              step="1"
            />
            <label htmlFor="floatingPassword" className='bg-transparent'>Año</label>
          </div>
          {/* <p className='text-start' style={{ textAlign: 'center', marginBottom: '10px' }} >Seleciona el piso:</p> */}
          <div className="text-center m-auto" style={chartIdStyle} >
            <div className="" >
            </div>
          </div>
          <DamageByRoomChart chartData={chartData} />
        </div>
        <div style={{ border: '1px solid #ccc', borderRadius: '5px', padding: '10px', marginBottom: '20px' }} >
          <h3 className='text-start' style={{ textAlign: 'center', marginBottom: '10px' }}>Gráfico de daños por habitación</h3>
          <p className='text-start' style={{ textAlign: 'center', marginBottom: '10px' }}>Seleciona el piso:</p>
          <select
            className="form-select h-100 bg-transparent text-center "
            onChange={(e) => {
              setSelectedFloor(parseInt(e.target.value));
              handleButtonClick(); // Llama a handleButtonClick después de actualizar selectedFloor
            }}
            defaultValue={selectedFloor}
          >
            {sortedFloors.map((floor) => (
              <option key={floor} value={floor} className='text-dark'>
                Piso {floor}
              </option>
            ))}
          </select>
          <div className="flex d-flex">
            <div className="form-floating">
              <input
                type="date"
                className="form-control input-text-custom w-auto"
                value={startDate.toISOString().slice(0, 10)}
                onChange={(e) => setStartDate(new Date(e.target.value))}
              />
              <label htmlFor="startDate" className="bg-transparent">Fecha de inicio</label>
            </div>
            <div>
              <h4 className='mt-3'>-</h4>
            </div>
            <div className="form-floating">
              <input
                type="date"
                className="form-control input-text-custom w-auto"
                value={endDate.toISOString().slice(0, 10)}
                onChange={(e) => setEndDate(new Date(e.target.value))}
              />
              <label htmlFor="endDate" className="bg-transparent">Fecha de fin</label>
            </div>
          </div>

          <div className="text-center m-auto" style={chartIdStyle} >
            <div className="" >
            </div>
          </div>
          <DamageByRoomChart chartData={chartDataSelectedFloor} />
        </div>
        <div style={{ border: '1px solid #ccc', borderRadius: '5px', padding: '10px', marginBottom: '20px' }}>
          <h3 className='text-center mb-4'>Gráfico de daños por rango de fechas</h3>
          <div className="d-flex mb-3">
            <div className="form-floating me-2">
              <input
                type="date"
                className="form-control input-text-custom"
                value={selectedStartDate.toISOString().slice(0, 10)}
                onChange={(e) => setSelectedStartDate(new Date(e.target.value))}
              />
              <label htmlFor="startDate" className="bg-transparent">Fecha de inicio</label>
            </div>
            <div><h4 className='mt-3'>-</h4></div>
            <div className="form-floating">
              <input
                type="date"
                className="form-control input-text-custom"
                value={selectedEndDate.toISOString().slice(0, 10)}
                onChange={(e) => setSelectedEndDate(new Date(e.target.value))}
              />
              <label htmlFor="endDate" className="bg-transparent">Fecha de fin</label>
            </div>
          </div>
          <div className="text-center m-auto" style={chartIdStyle} >
            <div className="" >

            </div>
          </div>
          <DamageByRoomChart chartData={chartDataMonth} />
        </div>
        <div>
          <div className="chart-container" style={{ border: '1px solid #ccc', borderRadius: '5px', padding: '10px', marginBottom: '20px' }}>
            <h3 style={{ textAlign: 'center', marginBottom: '10px' }}>Gráfico de informes por mes de un año</h3>
            <div className="form-floating ">
              <input
                type="number"
                className="form-control input-text-custom w-25"
                value={yearInput}
                onChange={handleYearInputChange}
                placeholder="Ingresa el año"
                min="2000" // Año mínimo permitido
                max={new Date().getFullYear()} // Año máximo permitido
                step="1"
              />
              <label htmlFor="floatingPassword" className='bg-transparent'>Fecha</label>
            </div>
            <ReportsByMonthChart reportsByMonthData={reportsByMonthData} />
          </div>
        </div>
      </div>
    </div>
  );
};
