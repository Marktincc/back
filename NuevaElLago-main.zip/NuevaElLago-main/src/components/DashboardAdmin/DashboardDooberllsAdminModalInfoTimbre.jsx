import React, { useState, useEffect } from 'react';
import axios from 'axios';

const apiUrl = import.meta.env.VITE_API_URL;

const ReportModal = ({ reportId, handleClose }) => {
  const [data, setData] = useState([]);

  const fetchData = async () => {
    try {
      const datosRecuperados = JSON.parse(sessionStorage.getItem('sessionData'));
      const response = await axios.get(`${apiUrl}/reportes/getReportById/${reportId}`, {
        headers: {
          Authorization: `Bearer ${datosRecuperados.token}`
        }
      });
      const formattedData = {
        ...response.data.body,
        createdAt: new Date(response.data.body.createdAt),
        completionDate: new Date(response.data.body.completionDate),
        updatedAt: new Date(response.data.body.updatedAt),
      };
      setData([formattedData]);
    } catch (error) {
      console.error('Error al obtener los datos:', error);
    }
  };

  useEffect(() => {
    fetchData();
  }, [reportId]);

  const calculateDaysInProgress = (startDate, endDate) => {
    const differenceInTime = endDate.getTime() - startDate.getTime();
    const differenceInDays = Math.floor(differenceInTime / (1000 * 3600 * 24));
    return differenceInDays >= 0 ? differenceInDays : 0;
  };

  return (
    <div>
      <div className="modal fade" id="exampleModal2" tabIndex="-1" aria-labelledby="staticBackdropLabel">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title" id="staticBackdropLabel">Foto del reporte del timbre</h5>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              {data.map(item => (
                <div key={item._id} className="report-item">
                  <h4>Detalles del reporte:</h4>
                  <ul>
                    <li><strong>Fecha de creación:</strong> {item.createdAt.toLocaleString()}</li>
                    <li><strong>Fecha de finalización:</strong> {item.completionDate.toLocaleString()}</li>
                    <li><strong>Tipo de daño:</strong> {item.damageType}</li>
                    <li><strong>Diagnóstico:</strong> {item.diagnosis || 'No especificado'}</li>
                    <li><strong>Piso:</strong> {item.floor}</li>
                    {item.status === 'en curso' && (
                      <li><strong>Días en curso:</strong> {calculateDaysInProgress(item.createdAt, new Date())}</li>
                    )}
                    {item.status === 'completado' && (
                      <li><strong>Días que se demoró en completar:</strong> {calculateDaysInProgress(item.createdAt, item.completionDate)}</li>
                    )}
                    {item.status === 'pendiente' && (
                      <li><strong>Días pendientes:</strong> {calculateDaysInProgress(item.createdAt, new Date())}</li>
                    )}
                    {item.photos && item.photos.length > 0 && (
                      <li>
                        <strong>Fotos:</strong>
                        <ul>
                          {item.photos.map((photo, index) => (
                            <li key={index}>{photo}</li>
                          ))}
                        </ul>
                      </li>
                    )}
                    <li><strong>Solicitud:</strong> {item.request}</li>
                    <li><strong>Responsable:</strong> {item.responsible || 'No especificado'}</li>
                    <li><strong>Habitación:</strong> {item.room}</li>
                    <li><strong>Estado:</strong> {item.status}</li>
                    <li><strong>Última actualización:</strong> {item.updatedAt.toLocaleString()}</li>
                  </ul>
                </div>
              ))}
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReportModal;
