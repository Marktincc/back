export const DashboardRouterAdmin = () => {
  return (
    <>
    <Toaster/>
      <Routes>
        <Route path='/Index' element={<DashboardAdminIndex />} />
        <Route path='/ProductsAdd' element={<DashboardAdminProductsAdd/>} />
        <Route path='/Order' element={<DashboardAdminOrder/>} />
        <Route path='/Category' element={<DashboardAdminCategory/>} />


        {/* <Route path='/Medico' element={<DashboardMedicoUser />} /> */}
      </Routes>

      <div className="container-fluid">
        <div className="row">
          <DashboardMenuAdmin />
          {/* <DashboardDesignAdmin /> */}
        </div>
      </div>
    </>
  );
}