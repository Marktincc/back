import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

const RouteEncript = ({ element }) => {
  const [rolUsuario, setRolUsuario] = useState(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    // Obtener el rol del usuario del sessionStorage
    const datos = JSON.parse(sessionStorage.getItem('sessionData'));

    // Comprobar si los datos de sesión existen y contienen la propiedad 'role'
    if (datos && datos.role) {
      setRolUsuario(datos.role); // Establecer el rol del usuario
    } else {
      // Redirigir al usuario al inicio de sesión si no hay datos de sesión o falta la propiedad 'role'
      navigate('/');
    }
  }, [navigate]);

  useEffect(() => {
    // Verificar el rol del usuario al cambiar el estado del rol
    if (rolUsuario !== null) {
      // Si el rol del usuario es "admin" y está intentando acceder a una ruta de usuario, redirigir al inicio de sesión
      if (rolUsuario === 'admin' && location.pathname.startsWith('/user')) {
        navigate('/');
      }
      // Si el rol del usuario es "user" y está intentando acceder a una ruta de admin, redirigir al inicio de sesión
      if (rolUsuario === 'user' && location.pathname.startsWith('/admin')) {
        navigate('/');
      }
    }
  }, [rolUsuario, location.pathname, navigate]);

  // Retornar el elemento si el rol del usuario es válido
  return rolUsuario !== null ? element : null;
};

export default RouteEncript;
