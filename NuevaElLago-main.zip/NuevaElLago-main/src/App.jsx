
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import './App.css'
import { DashboardMenuAdmin } from '@componentsadmin/DashboardMenuAdmin'
import { DashboardMenuUser } from '@componentsusers/DashboardMenuUser'
import { DashboardStatisticsAdmin } from '@componentsadmin/DashboardStatisticsAdmin'
import { DashboardDooberllsAdmin } from '@componentsadmin/DashboardDooberllsAdmin'
import { DashboardDooberllsUser } from '@componentsusers/DashboardDooberllsUser'

import { IndexStyle } from '@components/Index/IndexStyle'
import { Toaster } from 'react-hot-toast';
import DashboardRecordAdmin from './components/DashboardAdmin/DashboardRecordAdmin'
import RouteEncript from './RouteEncript';
import { DashboardStatisticsUser } from '@componentsusers/DashboardStatisticsUser'


// import { DashboardDooberllsAdmin } from '@componentsadmin/DashboardDooberllsAdmin'
// import "./node_modules/bootstrap/scss/bootstrap"
// import "../node_modules/bootstrap/scss/bootstrap"

function App() {

  return (
    <>
      <Toaster />
      <BrowserRouter>
        <main>
          <Routes basename="/myapp">
            <Route path='/' element={<IndexStyle />} />
            <Route path='/admin' element={<RouteEncript element={<DashboardMenuAdmin />} />} >
              <Route path='index' element={<DashboardStatisticsAdmin />} />
              <Route path='dooberlls' element={<DashboardDooberllsAdmin />} />
              <Route path='record' element={<DashboardRecordAdmin />} />

              {/* <Route path='settings' element={<SettingsPage />} /> */}
            </Route>
            <Route path='/user' element={<RouteEncript element={<DashboardMenuUser />} />} >
              <Route path='index' element={<DashboardStatisticsUser />} />
              <Route path='dooberlls' element={<DashboardDooberllsUser />} />

              {/* <Route path='settings' element={<SettingsPage />} /> */}
            </Route>
            <Route path='*' element={'404'} />
          </Routes>
        </main>
      </BrowserRouter>
    </>
  )
}

export default App
